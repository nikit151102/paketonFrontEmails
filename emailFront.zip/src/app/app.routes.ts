import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: '', loadChildren: () => import('./mail/mail.module').then(m => m.MailModule)
    },
    {
        path: 'franchise', loadChildren: () => import('./franchise/franchise.module').then(m => m.FranchiseModule)
    }
];
