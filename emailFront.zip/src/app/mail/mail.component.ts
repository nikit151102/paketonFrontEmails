import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MailService } from './mail.service';
import { FormBuilder, FormGroup, FormsModule, Validators } from '@angular/forms';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ReactiveFormsModule } from '@angular/forms';
import { EditorModule } from 'primeng/editor';
@Component({
  selector: 'app-mail',
  imports: [CommonModule, FormsModule, InfiniteScrollModule, EditorModule, ReactiveFormsModule],
  standalone: true,
  templateUrl: './mail.component.html',
  styleUrl: './mail.component.scss'
})
export class MailComponent implements OnInit {
  emails: any[] = [];
  newEmail: string = '';
  emailId: string = '';
  editedEmail: string = '';
  displayDialog: boolean = false;
  isEditMode: boolean = false;
  selectedFile: File | null = null;
  skip: number = 0;  // Сдвиг для пагинации
  limit: number = 50; // Количество сообщений на страницу
  isLoading: boolean = false;  // Для предотвращения множественных запросов
  scrollDistance: number = 1;
  editMail: boolean = false;
  taskId: string = 'unique-task-id';  // Уникальный ID задачи для WebSocket
  messageLog: string[] = [];
  selectedFileName: string | null = null;
  isAscending: boolean = true; // Порядок сортировки
  totalEmails: number = 0; 
  // Метод для сортировки по дате
  sortEmailsByDate(): void {
    this.isAscending = !this.isAscending; // Меняем порядок сортировки

    this.emails.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return this.isAscending ? dateA.getTime() - dateB.getTime() : dateB.getTime() - dateA.getTime();
    });
  }
  
  constructor(private mailService: MailService, private fb: FormBuilder,
  ) {


    this.standardMessageForm = this.fb.group({
      subject: ['', Validators.required],
      message: ['', Validators.required],
      min_interval: [33, [Validators.required, Validators.min(1)]],
      max_interval: [87, [Validators.required]],  // Интервал отправки в минутах
      emailsPerPage: [10, [Validators.required, Validators.min(1)]],  // Количество писем на страниц
      file: [null]
    });

    this.customMessageForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      subject: ['', Validators.required],
      message: ['', Validators.required],
      file: [null]
    });
  }

  ngOnInit(): void {
    this.loadMessages();
  }

  loadMessages(): void {
    if (this.isLoading) return;  // Предотвращаем загрузку, если уже идет запрос
    this.isLoading = true;

    this.mailService.getMessages(this.skip, this.limit).subscribe(
      (data) => {
        this.totalEmails = data.total
        this.emails = [...this.emails, ...data.emails];  // Добавляем новые данные в существующий массив
        this.skip += this.limit;  // Увеличиваем сдвиг для следующего запроса
        this.isLoading = false;
      },
      (error) => {
        alert('Не удалось загрузить письма');
        this.isLoading = false;
      }
    );
  }

  onScroll(): void {
    this.loadMessages();
  }

  createEmail(): void {
    if (!this.newEmail) {
      alert('Пожалуйста, введите email');
      return;
    }
    this.mailService.createEmail(this.newEmail).subscribe(
      (response) => {
        this.loadMessages();
        this.newEmail = '';
        alert('Email успешно создан');
      },
      (error) => {
        alert('Не удалось создать email');
      }
    );
  }

  openEditDialog(email: any): void {
    this.isEditMode = true;
    this.emailId = email.id;
    this.editedEmail = email.email;
    this.displayDialog = true;
    this.editMail = true;
  }

  editEmail(): void {
    if (!this.editedEmail) {
      alert('Пожалуйста, введите email');
      return;
    }
    this.mailService.editEmail(this.emailId, this.editedEmail).subscribe(
      (response) => {
        this.loadMessages();
        this.displayDialog = false;
        this.editMail = false;
        alert('Email успешно обновлён');
      },
      (error) => {
        alert('Не удалось обновить email');
      }
    );
  }

  deleteEmail(id: string): void {
    this.mailService.deleteEmail(id, '').subscribe(
      (response) => {
        this.skip = 0;
        this.emails = this.emails.filter(email => email.id !== id);
      },
      (error) => {
        alert('Не удалось удалить email');
      }
    );
  }


  closeDialog(): void {
    this.displayDialog = false;
    this.editMail = false;
    this.onRemoveFile();
  }

  uploadFile(): void {
    if (!this.selectedFile) {
      alert('Пожалуйста, выберите файл');
      return;
    }
    console.log('Selected file:', this.selectedFile);
    this.mailService.createAllEmail(this.selectedFile).subscribe(
      (response) => {
        this.skip = 0;
        this.emails = [];
        this.loadMessages();
        alert(`
         Файл успешно загружен!
          
          Детали:
          - Успешно загружено записей: ${response.loaded} 
          - Уже существующих в базе записей: ${response.skipped} 
          - Не валидных записей: ${response.invalid} 
          `);

      },
      (error) => {
        alert('Не удалось загрузить файл');
      }
    );
  }



  // Для формы стандартного сообщения
  standardMessageForm!: FormGroup;

  // Для формы пользовательского сообщения
  customMessageForm!: FormGroup;
  isCustomMessageDialog: boolean = false;

  // Метод для открытия диалога стандартного сообщения
  openStandardMessageDialog(): void {
    this.isCustomMessageDialog = false;  // Это диалог для стандартного сообщения
    this.displayDialog = true;
  }

  // Метод для открытия диалога кастомного сообщения
  openCustomMessageDialog(): void {
    this.isCustomMessageDialog = true;  // Это диалог для кастомного сообщения
    this.displayDialog = true;
  }

  // Метод отправки стандартного сообщения
  sendStandardMessage(): void {
    console.log('sendStandardMessage');
    if (this.standardMessageForm.invalid) {
      alert('Пожалуйста, заполните все поля');
      return;
    }

    const formData = this.standardMessageForm.value;
    if (this.selectedFile)
      this.mailService.sendMessages(formData, this.selectedFile).subscribe(
        (response) => {
          alert('Сообщение отправлено');
          this.displayDialog = false;
          this.standardMessageForm.reset();
        },
        (error) => {
          alert('Не удалось отправить сообщение');
        }
      );
  }

  // Метод для обработки выбора файла в кастомном сообщении
  onFileSelected(event: any): void {
    const file = event.target.files[0];
    console.log('event', file);

    if (file) {
      this.selectedFile = file; // Сохраняем выбранный файл
      this.selectedFileName = file.name; // Сохраняем имя файла
    } else {
      this.selectedFile = null; // Если файл не выбран
      this.selectedFileName = null;
    }
  }

  // Метод для удаления выбранного файла
  onRemoveFile(): void {
    this.selectedFile = null; // Очищаем выбранный файл
    this.selectedFileName = null; // Очищаем имя файла
    // Дополнительно можно сбросить значение в input, чтобы убрать файл из поля выбора
    const fileInput: HTMLInputElement | null = document.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = ''; // Очищаем поле ввода файла
    }
  }


  // Метод отправки кастомного сообщения
  sendCustomMessage(): void {
    if (this.customMessageForm.invalid) {
      alert('Пожалуйста, заполните все поля');
      return;
    }

    const { email, subject, message } = this.customMessageForm.value;
    if (this.selectedFile)
      this.mailService.sendCustomMessage(email, subject, message, this.selectedFile).subscribe(
        (response) => {
          alert('Кастомное сообщение отправлено');
          this.displayDialog = false;
          this.customMessageForm.reset();
          this.selectedFile = null;
          this.selectedFileName = null;
        },
        (error) => {
          alert('Не удалось отправить кастомное сообщение');
        }
      );
  }
}
