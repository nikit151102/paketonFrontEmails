import { Component, OnInit } from '@angular/core';
import { FranchiseRequest, FranchiseService } from './franchise.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';

@Component({
  selector: 'app-franchise',
  imports: [CommonModule, FormsModule, TableModule, ButtonModule, DialogModule],
  templateUrl: './franchise.component.html',
  styleUrl: './franchise.component.scss'
})
export class FranchiseComponent implements OnInit {
  franchiseRequests: FranchiseRequest[] = [];
  selectedRequest: FranchiseRequest | null = null;
  newRequest: FranchiseRequest = {
    full_name: '',
    phone: '',
    email: '',
    ownership_type: '',
    planned_investments: '',
    premises_type: '',
    franchise_source: ''
  };
  visible: boolean = false;
  isEdit: boolean = false;

  showDialogCreate(visibleEdit:boolean, request: any = '') {
    this.visible = true;
    if(visibleEdit === false){
      this.isEdit = false;
      this.clearForm();
    }else if(visibleEdit == true){
      this.isEdit = true;
      this.newRequest = request;
    }
    
  }

  constructor(private franchiseService: FranchiseService) { }

  ngOnInit(): void {
    this.loadFranchiseRequests();
  }

  // Загрузка заявок на франшизу
  loadFranchiseRequests(): void {
    this.franchiseService.getFranchiseRequests().subscribe((data) => {
      this.franchiseRequests = data;
    });
  }

  // Создание новой заявки
  createFranchiseRequest(): void {
    const formData = new FormData();
    formData.append("full_name", this.newRequest.full_name);
    formData.append("phone", this.newRequest.phone);
    formData.append("email", this.newRequest.email);
    formData.append("ownership_type", this.newRequest.ownership_type);
    formData.append("planned_investments", this.newRequest.planned_investments);
    formData.append("premises_type", this.newRequest.premises_type);
    formData.append("franchise_source", this.newRequest.franchise_source);

    // Отправка запроса с использованием FormData
    this.franchiseService.createFranchiseRequest(formData).subscribe((response: any) => {
      this.loadFranchiseRequests();
      this.visible = false;
      this.clearForm();
    });
  }

  clearForm() {
    this.newRequest = {
      full_name: '',
      phone: '',
      email: '',
      ownership_type: '',
      planned_investments: '',
      premises_type: '',
      franchise_source: ''
    };
  }

  // Получение заявки по ID
  getFranchiseRequestById(requestId: string | undefined): void {
    if (requestId)
      this.franchiseService.getFranchiseRequestById(requestId).subscribe((data) => {
        this.selectedRequest = data;
      });
  }

  // Обновление заявки
  updateFranchiseRequest(): void {
    if (this.newRequest) {
      console.log('newRequest,', this.newRequest)
      this.franchiseService.updateFranchiseRequest(this.newRequest.id!, this.newRequest).subscribe((data) => {
        console.log('updateFranchiseRequest')
        const index = this.franchiseRequests.findIndex((req) => req.id === data.id);
        if (index !== -1) {
          this.franchiseRequests[index] = data;
        }
        this.selectedRequest = null;
        this.loadFranchiseRequests();
      });
    }
  }

  // Удаление заявки
  deleteFranchiseRequest(requestId: string | undefined): void {
    if (requestId)
      this.franchiseService.deleteFranchiseRequest(requestId).subscribe(() => {
        this.franchiseRequests = this.franchiseRequests.filter((req) => req.id !== requestId);
      });
  }
}