import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FranchiseRoutingModule } from './franchise-router-module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FranchiseRoutingModule
  ]
})
export class FranchiseModule { }
