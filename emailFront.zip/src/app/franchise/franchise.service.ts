import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../evirement';


export interface FranchiseRequest {
  id?: string;
  full_name: string;
  phone: string;
  email: string;
  ownership_type: string;
  planned_investments: string;
  premises_type: string;
  franchise_source: string;
  date_submitted?: string;
}

@Injectable({
  providedIn: 'root',
})
export class FranchiseService {
  private apiUrl = `${environment.apiUrl}/franchise`;

  constructor(private http: HttpClient) {}

  // Получить все заявки
  getFranchiseRequests(skip: number = 0, limit: number = 100000): Observable<FranchiseRequest[]> {
    return this.http.get<FranchiseRequest[]>(`${this.apiUrl}/franchise-requests?skip=${skip}&limit=${limit}`);
  }

  // Создать новую заявку
createFranchiseRequest(formData: FormData): Observable<any> {
  return this.http.post<any>(`${this.apiUrl}/franchise-request/`, formData);
}


  // Получить заявку по ID
  getFranchiseRequestById(requestId: string): Observable<FranchiseRequest> {
    return this.http.get<FranchiseRequest>(`${this.apiUrl}/franchise-request/${requestId}`);
  }

  // Обновить заявку
  updateFranchiseRequest(requestId: string, request: FranchiseRequest): Observable<FranchiseRequest> {
    return this.http.put<FranchiseRequest>(`${this.apiUrl}/franchise-request/${requestId}`, request);
  }

  // Удалить заявку
  deleteFranchiseRequest(requestId: string): Observable<FranchiseRequest> {
    return this.http.delete<FranchiseRequest>(`${this.apiUrl}/franchise-request/${requestId}`);
  }
}
